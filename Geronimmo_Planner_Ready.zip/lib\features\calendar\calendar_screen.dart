import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:table_calendar/table_calendar.dart';
import 'package:geronimmo_planner/core/l10n/app_localizations.dart';
import 'package:geronimmo_planner/core/providers/providers.dart';
import 'package:geronimmo_planner/models/event_model.dart';

class CalendarScreen extends ConsumerStatefulWidget {
  const CalendarScreen({super.key});

  @override
  ConsumerState<CalendarScreen> createState() => _CalendarScreenState();
}

class _CalendarScreenState extends ConsumerState<CalendarScreen> {
  DateTime _focusedDay = DateTime.now();
  DateTime? _selectedDay;
  CalendarFormat _calendarFormat = CalendarFormat.month;

  @override
  Widget build(BuildContext context) {
    final loc = AppLocalizations.of(Localizations.localeOf(context));
    final events = ref.watch(eventsProvider);

    final selectedDay = _selectedDay ?? _focusedDay;
    final dayEvents = events.where((e) =>
      e.start.year == selectedDay.year &&
      e.start.month == selectedDay.month &&
      e.start.day == selectedDay.day
    ).toList();

    return Scaffold(
      appBar: AppBar(
        title: Text(loc.calendar),
        actions: [
          IconButton(
            icon: const Icon(Icons.add),
            onPressed: () => _addEvent(context, selectedDay),
          ),
        ],
      ),
      body: Column(
        children: [
          TableCalendar<EventModel>(
            firstDay: DateTime.utc(2020, 1, 1),
            lastDay: DateTime.utc(2030, 12, 31),
            focusedDay: _focusedDay,
            selectedDayPredicate: (day) => isSameDay(_selectedDay, day),
            calendarFormat: _calendarFormat,
            onDaySelected: (selected, focused) {
              setState(() {
                _selectedDay = selected;
                _focusedDay = focused;
              });
            },
            onFormatChanged: (format) => setState(() => _calendarFormat = format),
            eventLoader: (day) => events.where((e) =>
              e.start.year == day.year && e.start.month == day.month && e.start.day == day.day).toList(),
            calendarStyle: const CalendarStyle(
              markersMaxCount: 3,
              markerDecoration: BoxDecoration(color: Colors.blue, shape: BoxShape.circle),
            ),
          ),
          const Divider(height: 1),
          Expanded(
            child: dayEvents.isEmpty
                ? Center(child: Text(loc.noEvents))
                : ListView.builder(
                    itemCount: dayEvents.length,
                    itemBuilder: (ctx, i) {
                      final ev = dayEvents[i];
                      return Card(
                        margin: const EdgeInsets.symmetric(horizontal: 12, vertical: 4),
                        child: ListTile(
                          leading: Container(width: 12, color: Color(int.parse(ev.colorHex.replaceAll('#', '0xff')))),
                          title: Text(ev.title),
                          subtitle: Text('${ev.start.hour}:${ev.start.minute.toString().padLeft(2, '0')} - ${ev.end.hour}:${ev.end.minute.toString().padLeft(2, '0')}'),
                          onTap: () => _addEvent(context, selectedDay, existing: ev),
                        ),
                      );
                    },
                  ),
          ),
        ],
      ),
    );
  }

  void _addEvent(BuildContext context, DateTime day, {EventModel? existing}) {
    final titleCtrl = TextEditingController(text: existing?.title ?? 'New Meeting');
    showDialog(
      context: context,
      builder: (_) => AlertDialog(
        title: Text(existing == null ? 'New Event' : 'Edit Event'),
        content: TextField(controller: titleCtrl),
        actions: [
          TextButton(onPressed: () => Navigator.pop(context), child: const Text('Cancel')),
          FilledButton(
            onPressed: () {
              final now = DateTime.now();
              final start = DateTime(day.year, day.month, day.day, now.hour, now.minute);
              final end = start.add(const Duration(hours: 1));

              final event = (existing ?? EventModel(title: '', start: start, end: end)).copyWith(
                title: titleCtrl.text,
                start: start,
                end: end,
              );
              ref.read(eventsProvider.notifier).addOrUpdate(event);
              Navigator.pop(context);
            },
            child: const Text('Save'),
          ),
        ],
      ),
    );
  }
}
