import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:geronimmo_planner/core/l10n/app_localizations.dart';

class NotesScreen extends ConsumerWidget {
  const NotesScreen({super.key});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final loc = AppLocalizations.of(Localizations.localeOf(context));
    return Scaffold(
      appBar: AppBar(title: Text(loc.notes)),
      body: Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            const Icon(Icons.note_alt_outlined, size: 64, color: Colors.grey),
            const SizedBox(height: 16),
            Text(loc.empty_state_general),
            const SizedBox(height: 8),
            const Text('Notes are linked to tasks and events in this version.'),
            const SizedBox(height: 24),
            ElevatedButton(
              onPressed: () {},
              child: Text(loc.quickNote),
            ),
          ],
        ),
      ),
    );
  }
}
