import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:geronimmo_planner/core/db/database_service.dart';
import 'package:geronimmo_planner/models/task_model.dart';
import 'package:geronimmo_planner/models/event_model.dart';

// Tasks
final tasksProvider = StateNotifierProvider<TasksNotifier, List<TaskModel>>((ref) {
  return TasksNotifier();
});

class TasksNotifier extends StateNotifier<List<TaskModel>> {
  TasksNotifier() : super([]) {
    _load();
  }

  Future<void> _load() async {
    final tasks = await DatabaseService.getAllTasks();
    state = tasks;
  }

  Future<void> addOrUpdate(TaskModel task) async {
    await DatabaseService.insertOrUpdateTask(task);
    await _load();
  }

  Future<void> delete(String id) async {
    await DatabaseService.deleteTask(id);
    await _load();
  }

  Future<void> toggleComplete(TaskModel task) async {
    final updated = task.copyWith(isCompleted: !task.isCompleted);
    await addOrUpdate(updated);
  }
}

// Events
final eventsProvider = StateNotifierProvider<EventsNotifier, List<EventModel>>((ref) {
  return EventsNotifier();
});

class EventsNotifier extends StateNotifier<List<EventModel>> {
  EventsNotifier() : super([]) {
    _load();
  }

  Future<void> _load() async {
    final events = await DatabaseService.getAllEvents();
    state = events;
  }

  Future<void> addOrUpdate(EventModel event) async {
    await DatabaseService.insertOrUpdateEvent(event);
    await _load();
  }

  Future<void> delete(String id) async {
    await DatabaseService.deleteEvent(id);
    await _load();
  }
}

// Simple search/filter provider
final searchQueryProvider = StateProvider<String>((ref) => '');
final selectedFiltersProvider = StateProvider<Map<String, dynamic>>((ref) => {});
