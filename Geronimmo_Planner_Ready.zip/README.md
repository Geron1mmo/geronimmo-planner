# Geronimmo Planner

**Beautiful, simple, fast, multilingual planner** for personal life, work, meetings, tasks, reminders, habits and daily productivity.

Created by **Geronimmo & Oleg**.

Cross-platform production-ready app:
- Windows Desktop
- Android
- iOS (iPhone)

Single Flutter codebase. Local-first with reliable storage. Ready for future cloud sync.

## Features (implemented)

- Full Calendar (Day / Week / Month / Timeline)
- Powerful Tasks with priorities, statuses, categories, subtasks, notes
- Events & Meetings with repeat, reminders, participants
- Smart Reminders + local push notifications (with snooze)
- Recurring items with skip single occurrence
- Smart Dashboard (Today, Overdue, "What should I do now?", Productivity score, Morning plan, Evening review, Free time finder)
- Quick Notes linked to items
- Powerful search + filters
- Full Settings (language, theme, accent color, week start, time format, backup/export/import JSON, safe reset)
- 4 languages: Ukrainian, Russian, Czech, English (full coverage of UI, notifications, errors, empty states)
- Premium clean modern UI with smooth animations, Material 3, dark/light + accent colors
- Local persistent storage (sqflite)
- JSON backup / import (future-proof for cloud)
- Professional icons, splash screen, packaging ready

## Project Structure

```
geronimmo_planner/
├── lib/
│   ├── main.dart
│   ├── app.dart
│   ├── core/
│   │   ├── constants/
│   │   ├── l10n/               # translations
│   │   ├── theme/
│   │   ├── utils/
│   │   └── db/                 # database + repositories
│   ├── features/
│   │   ├── dashboard/
│   │   ├── calendar/
│   │   ├── tasks/
│   │   ├── events/
│   │   ├── reminders/
│   │   ├── notes/
│   │   └── settings/
│   ├── models/                 # pure data models + recurrence
│   └── widgets/                # shared reusable widgets
├── assets/
│   ├── icons/
│   └── images/
├── test/                       # basic tests
├── android/ ios/ windows/      # platform folders (auto)
├── pubspec.yaml
└── README.md
```

## Getting Started

### Prerequisites

- Flutter 3.22+
- For Android: Android Studio / SDK + emulator or device
- For iOS build: Mac + Xcode (code runs on any machine)
- For Windows desktop: Visual Studio 2022 Community with "Desktop development with C++" workload

### Install & Run

```powershell
# 1. Navigate to the project
cd geronimmo_planner

# 2. Get dependencies
flutter pub get

# 3. Run on Windows Desktop (recommended first)
flutter run -d windows

# 4. Run on Android
flutter run -d android

# 5. Run on iOS (Mac only)
flutter run -d ios
```

### Build Production

**Android APK:**
```bash
flutter build apk --release
# Output: build/app/outputs/flutter-apk/app-release.apk
```

**Android App Bundle (Google Play):**
```bash
flutter build appbundle --release
```

**Windows Desktop:**
```powershell
flutter build windows --release
# The .exe will be in: build\windows\x64\runner\Release\Geronimmo Planner.exe
```

**iOS (Mac + Xcode required for final archive):**
```bash
flutter build ios --release
# Open ios/Runner.xcworkspace in Xcode → Archive → Distribute
```

### App Icons & Splash Screen

Place your 1024x1024 icon at `assets/icons/app_icon.png`.

Then run:
```bash
flutter pub run flutter_launcher_icons
flutter pub run flutter_native_splash:create
```

The configuration is already in pubspec.yaml.

### First Run Notes

- The app uses local SQLite storage (persists after close).
- Sample data can be added manually via the UI (tasks, events).
- Language switcher is in Settings.
- All data is backed up via Settings → Backup & Export (JSON).

## App Icons & Splash

Icons and splash are configured in pubspec.yaml.

To regenerate after changing assets/icons/app_icon.png:

```bash
flutter pub run flutter_launcher_icons
flutter pub run flutter_native_splash:create
```

## Data & Backup

- All data stored locally in SQLite (cross-platform).
- Use Settings → Backup & Export to save full JSON backup.
- Import JSON safely merges or replaces.
- Safe "Reset App" option in settings (with confirmation).

## Languages

Switch in **Settings → Language**.

Supported:
- English (fallback)
- Українська (Ukrainian)
- Русский (Russian)
- Čeština (Czech)

All UI, buttons, empty states, notifications, onboarding, errors are translated.

## Architecture Highlights (Production Ready)

- Clean feature-based structure
- Riverpod for reactive state
- GoRouter for navigation
- sqflite + FFI for reliable local persistence (no data loss)
- Recurrence engine with skip support
- Notification scheduler with unique IDs to avoid duplicates
- Timezone-aware DateTime handling (stores in UTC + local display)
- Full form validation + edge case handling
- Reusable components and cards
- Loading / Error / Empty states everywhere
- No hardcoded strings (all via AppLocalizations)

## Testing

Basic unit tests included in `test/` for:
- Recurrence engine
- Date utilities
- Database save/load roundtrip
- Translation coverage check (scriptable)

Manual QA checklist is in this README (see below).

## QA Checklist (Manual)

- [ ] Create/edit/delete task with all fields + subtasks
- [ ] Mark complete / change priority / status
- [ ] Create event with repeat (weekly + skip one)
- [ ] Set reminders and verify they fire (on device)
- [ ] Snooze reminder
- [ ] Calendar: switch Day/Week/Month/Timeline, drag events (desktop)
- [ ] Today dashboard shows correct overdue + suggestions
- [ ] Search + all filters work across data
- [ ] Language switch updates everything live
- [ ] Theme + accent color change
- [ ] Export JSON → clear data → Import works
- [ ] No crashes on edge dates (leap year, DST, year boundary)
- [ ] Notifications don't duplicate
- [ ] Desktop build runs and notifications show (if supported)
- [ ] Mobile builds install and run

## Future Improvements (Roadmap)

- Cloud sync (Firebase / Supabase / custom) behind feature flag
- Habit tracker module
- Pomodoro / Focus timer with integration to tasks
- AI smart suggestions ("Based on your unfinished work...")
- Calendar sharing / collaboration
- Widgets for home screen (Android/iOS)
- Desktop tray + global hotkey quick add
- Offline-first conflict resolution
- Export to ICS / PDF reports
- Darker / custom themes + more accent palettes
- Biometric lock
- Wear OS / Watch companion

## License & Credits

Created by Geronimmo & Oleg.  
All rights reserved.

---

**Enjoy planning with Geronimmo Planner!**
